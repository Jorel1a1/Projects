package com.droiduino.bluetoothconn;

import static com.droiduino.bluetoothconn.MainActivity.connectedThread;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EndPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_page);
        connectedThread.write("0 0 0 0");
        GettingBlutoothInfo gettingBlutoothInfo = GettingBlutoothInfo.getInstance();
        gettingBlutoothInfo.settapcount(0);
    }
}