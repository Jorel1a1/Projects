package com.droiduino.bluetoothconn;

import androidx.appcompat.app.AppCompatActivity;

import static com.droiduino.bluetoothconn.MainActivity.connectedThread;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class ConfirmationPage extends AppCompatActivity {
    private TextView time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation_page);
        connectedThread.write("2 0 15 0");
        GettingBlutoothInfo gettingBlutoothInfo = GettingBlutoothInfo.getInstance();
        //Log.i("Hell", gettingBlutoothInfo.getData());
    }

}