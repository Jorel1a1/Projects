package com.droiduino.bluetoothconn;

import android.content.Intent;

public class GettingBlutoothInfo {
    private static GettingBlutoothInfo instance;

    // Global variable
    private String data = null;
    private int tapcount = 0;

    // Restrict the constructor from being instantiated
    private GettingBlutoothInfo(){}

    public void settapcount(int c) {
        this.tapcount = c;
    }
    public int gettappcount(){
        return this.tapcount;
    }

    public void setData(String d){
        this.data=d;
    }
    public String getData(){
        return this.data;
    }

    public static synchronized GettingBlutoothInfo getInstance(){
        if(instance==null){
            instance=new GettingBlutoothInfo();
        }
        return instance;
    }
}
