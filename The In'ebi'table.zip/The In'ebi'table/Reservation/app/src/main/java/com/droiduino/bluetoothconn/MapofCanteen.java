package com.droiduino.bluetoothconn;

import static com.droiduino.bluetoothconn.MainActivity.connectedThread;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MapofCanteen extends AppCompatActivity {
    ViewGroup layout;
    private Button confirm;
    List<TextView> seatViewList = new ArrayList<>();
    int seatSize = 100;
    int seatGaping = 10;
    int STATUS_AVAILABLE = 1;
    int STATUS_BOOKED = 2;
    int STATUS_RESERVED = 3;
    String selectedIds = "";
    String seats =
            "_________UUUUUAAAA/"
                    + "_________TTTTTTTTT/"
                    + "_________UUUUUAAAA/"
                    + "_________UUUUUAAAA/"
                    + "_________TTTTTTTTT/"
                    + "_________UUUUUAAAA/"
                    + "_________________/"
                    + "_________________/"
                    + "_________________/"
                    + "_________________/"
                    + "AAAAAA__AAAAAAAAAA/"
                    + "TTTTTT__TTTTTTTTTT/"
                    + "AAAAAA__AAAAAAAAAA/"
                    + "_________________/"
                    + "AAAAAA__AAAAAAAAAA/"
                    + "TTTTTT__TTTTTTTTTT/"
                    + "AAAAAA__AAAAAAAAAA/"
                    + "_________________/"
                    + "AAAAAA__AAAAAAAAAA/"
                    + "TTTTTT__TTTTTTTTTT/"
                    + "AAAAAA__AAAAAAAAAA/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapof_canteen);
        List <Integer> realId = new ArrayList<>();
        confirm = findViewById(R.id.confirm);
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MapofCanteen.this, ConfirmationPage.class);
                startActivity(intent);
            }
        });
        layout = findViewById(R.id.layoutSeat);
        seats = "/" + seats;


        LinearLayout layoutSeat = new LinearLayout(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutSeat.setOrientation(LinearLayout.VERTICAL);
        layoutSeat.setLayoutParams(params);
        layoutSeat.setPadding(8 * seatGaping, 8 * seatGaping, 8 * seatGaping, 8 * seatGaping);
        layout.addView(layoutSeat);

        LinearLayout layout = null;

        int count = 0;

        for (int index = 0; index < seats.length(); index++) {
            if (seats.charAt(index) == '/' ) {
                layout = new LinearLayout(this);
                layout.setOrientation(LinearLayout.HORIZONTAL);
                layoutSeat.addView(layout);
            } else if (seats.charAt(index) == 'U') {
                count++;
                TextView view = new TextView(this);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setId(count);
                view.setGravity(Gravity.CENTER);
                view.setBackgroundResource(R.drawable.ic_seats_booked);
                view.setTextColor(Color.WHITE);
                view.setTag(STATUS_BOOKED);
                view.setText(count + "");
                view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9);
                layout.addView(view);
                seatViewList.add(view);
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if ((int) view.getTag() == STATUS_AVAILABLE) {
                            if (selectedIds.contains(view.getId() + ",")) {
                                selectedIds = selectedIds.replace(+view.getId() + ",", "");
                                view.setBackgroundResource(R.drawable.ic_seats_book);
                            } else {
                                selectedIds = selectedIds + view.getId() + ",";
                                view.setBackgroundResource(R.drawable.ic_seats_selected);
                            }
                        } else if ((int) view.getTag() == STATUS_BOOKED) {
                            Toast.makeText(MapofCanteen.this, "Seat " + view.getId() + " is Booked", Toast.LENGTH_SHORT).show();
                        } else if ((int) view.getTag() == STATUS_RESERVED) {
                            Toast.makeText(MapofCanteen.this, "Seat " + view.getId() + " is Booked", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            } else if (seats.charAt(index) == 'A') {
                count++;
                TextView view = new TextView(this);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setId(count);
                view.setGravity(Gravity.CENTER);
                view.setBackgroundResource(R.drawable.ic_seats_book);
                view.setText(count + "");
                view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9);
                view.setTextColor(Color.BLACK);
                view.setTag(STATUS_AVAILABLE);
                layout.addView(view);
                seatViewList.add(view);
                int number = index;
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if ((int) view.getTag() == STATUS_AVAILABLE) {
                            if (selectedIds.contains(view.getId() + ",")) {
                                selectedIds = selectedIds.replace(+view.getId() + ",", "");
                                view.setBackgroundResource(R.drawable.ic_seats_book);
                                //realId.remove(Integer.valueOf(number));
                            } else {
                                selectedIds = selectedIds + view.getId() + ",";
                                view.setBackgroundResource(R.drawable.ic_seats_selected);
                                //realId.add(number);
                            }
                        } else if ((int) view.getTag() == STATUS_BOOKED) {
                            Toast.makeText(MapofCanteen.this, "Seat " + view.getId() + " is Booked", Toast.LENGTH_SHORT).show();
                        } else if ((int) view.getTag() == STATUS_RESERVED) {
                            Toast.makeText(MapofCanteen.this, "Seat " + view.getId() + " is Booked", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            } else if (seats.charAt(index) == 'T') {
                TextView view = new TextView(this);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setPadding(0, 0, 0, 2 * seatGaping);
                view.setId(count);
                view.setGravity(Gravity.CENTER);
                view.setBackgroundResource(R.drawable.ic_seats_reserved);
                view.setText("Table ");
                view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 9);
                view.setTextColor(Color.BLACK);
                view.setTag(STATUS_RESERVED);
                layout.addView(view);
                seatViewList.add(view);
            } else if (seats.charAt(index) == '_') {
                TextView view = new TextView(this);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(seatSize, seatSize);
                layoutParams.setMargins(seatGaping, seatGaping, seatGaping, seatGaping);
                view.setLayoutParams(layoutParams);
                view.setBackgroundColor(Color.TRANSPARENT);
                view.setText("");
                layout.addView(view);
            }
        }
    }
}