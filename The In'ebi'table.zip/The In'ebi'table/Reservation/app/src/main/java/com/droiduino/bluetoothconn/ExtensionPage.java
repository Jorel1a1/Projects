package com.droiduino.bluetoothconn;

import static com.droiduino.bluetoothconn.MainActivity.connectedThread;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ExtensionPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extension);
        connectedThread.write("3 0 1 0");
        GettingBlutoothInfo gettingBlutoothInfo = GettingBlutoothInfo.getInstance();
        gettingBlutoothInfo.settapcount(gettingBlutoothInfo.gettappcount() + 1);
    }
}