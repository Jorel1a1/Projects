package com.example.medireminder;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;

public class Splash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Remove title bar
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();

        //Load the Splash Screen layout
        setContentView(R.layout.splash);

        /*MediaPlayer mp = new MediaPlayer();
        try{
            mp.setDataSource("store_chime_trim.mp3");//Write your location here
            mp.prepare();
            mp.start();

        }catch(Exception e){e.printStackTrace();}
        */
        MediaPlayer ring= MediaPlayer.create(Splash.this,R.raw.chime);
        ring.start();

        final Handler handler = new Handler(); // Create a Handler on the main Thread
        handler.postDelayed(new Runnable(){
            public void run(){
                finish();
            }
        }, 2000); //Post back to the main Thread after 3000 mils (3 seconds)
    }
}