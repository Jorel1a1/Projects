package com.example.medireminder;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.CursorAdapter;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


public class AlarmList extends AppCompatActivity {
    private FloatingActionButton add;
    private Cursor model = null;
    private AlarmAdapter adapter = null;
    private ListView list;
    private AlarmHelper helper = null;
    private TextView empty;
    private GPSTracker gpsTracker;
    private double latitude = 0.0d;
    private double longitude = 0.0d;
    private double myLatitude = 0.0d;
    private double myLogitude = 0.0d;
    private String phoneID = "";
    //private Cursor model = null;
    private Dialog dialog;
    private PhoneNumberHelper helper1 = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intentAbout;                                                                         //Launch the Splash Image activity
        intentAbout = new Intent(AlarmList.this, Splash.class);
        startActivity(intentAbout);
        setContentView(R.layout.alarmlist);

        helper1 = new PhoneNumberHelper(this);
        helper1.getAll();

        add = findViewById(R.id.add);
        empty = findViewById(R.id.empty);
        helper = new AlarmHelper(this);
        list = findViewById(R.id.list);
        model = helper.getAll();
        adapter = new AlarmAdapter(this, model, 0);
        list.setOnItemClickListener(onListClick);
        //list.setOnItemLongClickListener(onLongListClick);
        list.setAdapter(adapter);
        gpsTracker = new GPSTracker(AlarmList.this);
        phoneID = getIntent().getStringExtra("ID");


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(helper1.sizeOfDatabase()==0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(AlarmList.this);            //Create a pop-up dialog

                    builder.setMessage("Phone Number is not registered!");
                    builder.setCancelable(true);
                    builder.setPositiveButton(
                            "Got it",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog alert = builder.create();                                           //Show the User the Alert Dialog
                    alert.show();
                } else {
                    Intent intent;
                    intent = new Intent(AlarmList.this, Details.class);
                    startActivity(intent);
                }

            }
        });
    }
    public boolean onPrepareOptionsMenu(Menu menu)
    {
        MenuItem registerButton = menu.findItem(R.id.addphone);
        if (helper1.sizeOfDatabase() == 0 ) registerButton.setTitle("Add Phone Number");                     //If registered show 'Unregister' and vice versa
        else registerButton.setTitle("Change Phone Number");

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    protected void onResume(){
        super.onResume();
        if (model != null) { model.close();}
        model = helper.getAll();
        if (model.getCount() > 0) { empty.setVisibility(View.INVISIBLE); }
        adapter.swapCursor(model);
    }

    @Override
    protected void onDestroy(){
        helper.close();
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.optionlist, menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case (R.id.deleteall):
                AlertDialog.Builder builder = new AlertDialog.Builder(this);            //Create a pop-up dialog

                builder.setMessage("Are you sure you want to delete everything?");
                builder.setCancelable(true);
                builder.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                helper.deleteDataBase();
                                Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+8:00"));
                                calendar.clear();
                                recreate();
                            }
                        });
                builder.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();                                           //Show the User the Alert Dialog
                alert.show();
                break;
            case (R.id.nearbypharmacies):
                if (gpsTracker.canGetLocation()) {
                    latitude = gpsTracker.getLatitude();
                    longitude = gpsTracker.getLongitude();
                    //location.setText(String.valueOf(latitude) + ", " + String.valueOf(longitude));

                    // \n is for new line
                   // Toast.makeText(getApplicationContext(), "Your location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
                    myLatitude = gpsTracker.getLatitude();
                    myLogitude = gpsTracker.getLongitude();

                    Intent intent = new Intent(AlarmList.this, PharmaciesMap.class);
                    intent.putExtra("LATITUDE", latitude);
                    intent.putExtra("LONGITUDE", longitude);
                    intent.putExtra("MYLATITUDE", myLatitude);
                    intent.putExtra("MYLONGITUDE", myLogitude);
                    //intent.putExtra("NAME", restaurantName.getText().toString());
                    startActivity(intent);
                    return true;

                }
                break;
            case (R.id.current):
                if(helper1.sizeOfDatabase()==0) {
                    AlertDialog.Builder builder1 = new AlertDialog.Builder(this);            //Create a pop-up dialog

                    builder1.setMessage("Phone Number is not registered");
                    builder1.setCancelable(true);
                    builder1.setPositiveButton(
                            "Got it",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog alert1 = builder1.create();                                           //Show the User the Alert Dialog
                    alert1.show();
                }
                else {
                    Cursor c = helper1.getAll();
                    c.moveToFirst();
                    Toast.makeText(getApplicationContext(), helper1.getPhoneNumber(c), Toast.LENGTH_LONG).show();
                }

                break;
            case (R.id.addphone):
                dialog = new Dialog(AlarmList.this);
                dialog.setContentView(R.layout.floating_popup);
                final EditText PhoneNumber = dialog.findViewById(R.id.PhoneNumber);
                Button save;
                save = dialog.findViewById(R.id.save);
                save.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(helper1.sizeOfDatabase() == 0) {
                            String PhoneNumberStr = PhoneNumber.getText().toString();
                            helper1.insert(PhoneNumberStr);
                            dialog.dismiss();

                        }
                        else {
                            phoneID = String.valueOf(helper1.sizeOfDatabase());
                            String PhoneNumberStr = PhoneNumber.getText().toString();
                            helper1.update(phoneID, PhoneNumberStr);
                            dialog.dismiss();
                        }

                    }
                });
                //dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
                break;


        }
        return super.onOptionsItemSelected(item);
    }

   /* private AdapterView.OnItemLongClickListener onLongListClick = new AdapterView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
            Intent intent = new Intent(AlarmList.this, Details.class);
            stopService(intent);

            model.moveToPosition(position);

            return false;
        }
    };*/



    private AdapterView.OnItemClickListener onListClick = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            model.moveToPosition(position);
            String recordID = helper.getID(model);
            Intent intent;
            intent = new Intent(AlarmList.this, Details.class);
            intent.putExtra("ID", recordID);
            startActivity(intent);
        }
    };

    static class AlarmHolder {
        private TextView medName = null;
        private TextView medIntake = null;
        private TextView date = null;


        AlarmHolder(View row) {
            medName = row.findViewById(R
                    .id.dis_name);
            medIntake = row.findViewById(R.id.dis_intake);
            date = row.findViewById(R.id.dis_date);
        }

        void populateFrom (Cursor c, AlarmHelper helper) {
            medName.setText(helper.getAlarmName(c));
            medIntake.setText(helper.getIntake(c));
            date.setText(helper.getDateandtime(c));

        }
    }

    class AlarmAdapter extends CursorAdapter {
        AlarmAdapter(Context context, Cursor cursor, int flags){
            super(context,cursor,flags);
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor){
            AlarmHolder holder = (AlarmHolder) view.getTag();
            holder.populateFrom(cursor, helper);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.row, parent, false);
            AlarmHolder holder = new AlarmHolder(row);
            row.setTag(holder);
            return(row);
        }
    }
}