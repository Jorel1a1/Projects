package com.example.medireminder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
//import android.support.v4.app.NotificationCompat;

import androidx.core.app.NotificationCompat;

import java.util.Date;

public class NotifierAlarm extends BroadcastReceiver {

    //private AppDatabase appDatabase;
    private String NameID;
    private String IntakeID;

    @Override
    public void onReceive(Context context, Intent intent) {

        //appDatabase = AppDatabase.geAppdatabase(context.getApplicationContext());
        //RoomDAO roomDAO = appDatabase.getRoomDAO();
        //Reminders reminder = new Reminders();
        //reminder.setMessage(intent.getStringExtra("Message"));
        //reminder.setRemindDate(new Date(intent.getStringExtra("RemindDate")));
        //reminder.setId(intent.getIntExtra("id",0));
        //roomDAO.Delete(reminder);
        //AppDatabase.destroyInstance();

        Uri alarmsound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        Bundle bundle = intent.getExtras();
        Intent intent1 = new Intent(context,Sendingsms.class);
        intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(context);
        taskStackBuilder.addParentStack(Sendingsms.class);
        taskStackBuilder.addNextIntent(intent1);
        NameID = bundle.getString("MedName");
        IntakeID = bundle.getString("MedIntake");
        Bundle bundle1 = new Bundle();
        bundle1.putString("NameofMed", NameID);
        bundle1.putString("IntakeofMed", IntakeID);
        intent1.putExtras(bundle1);


        PendingIntent intent2 = taskStackBuilder.getPendingIntent(1, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context);

        NotificationChannel channel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel("my_channel_01","hello", NotificationManager.IMPORTANCE_HIGH);
        }

        Notification notification = builder.setContentTitle("Reminder")
                .setContentText(bundle.getString("MedName") + " (" + bundle.getString("MedIntake")+ ")").setAutoCancel(true)
                .setSound(alarmsound).setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentIntent(intent2)
                .setChannelId("my_channel_01")
                .build();

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(channel);
        }
        notificationManager.notify(1, notification);

    }
}
