package com.example.medireminder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.room.util.TableInfo;

import java.util.Date;


public class AlarmHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "alarmlist.db";
    private static final int SCHEMA_VERSION = 1;
    private SQLiteDatabase db;
    public static final String COLOUM_PRODUCTNAME = "alarmName";

    public AlarmHelper(Context context) {
        super (context,DATABASE_NAME,null,SCHEMA_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        //Will be called once when the database is not created
        db.execSQL("CREATE TABLE alarm_table ( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "alarmName TEXT, dateandtime TEXT, intake TEXT);" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        //Will not be called until SCHEMA version increases
        //We can upgrade the database here e.g. add more tables
    }

    /*Read all records from restaurants_table */
    public Cursor getAll(){
        return (getReadableDatabase().rawQuery(
                "SELECT _id, alarmName," +
                        " dateandtime, intake FROM alarm_table ORDER BY alarmName",null));
    }

    /* Read a particular record from restaurants_table with id provided */
    public Cursor getById(String id) {
    String[] args = {id};
    return (getReadableDatabase().rawQuery(
            "SELECT _id, alarmName," +
                    "dateandtime, intake FROM alarm_table WHERE _ID = ?", args));
    }

    /*Writes a record into restaurants_table */
    public void insert(String alarmName, String dateandtime, String intake){
        ContentValues cv = new ContentValues();

        cv.put("alarmName", alarmName);
        cv.put("dateandtime", dateandtime);
        cv.put("intake", intake);

        getWritableDatabase().insert("alarm_table", "alarmName", cv);
    }

    /* Update a particular record in restaurants_table with id provided */
    public void update(String id, String alarmName, String dateandtime, String intake) {
        ContentValues cv = new ContentValues();
        String[] args = {id};

        cv.put("alarmName", alarmName);
        cv.put("dateandtime", dateandtime);
        cv.put("intake", intake);

        getWritableDatabase().update("alarm_table", cv, "_ID = ?", args);
    }

    public void deleteDataBase (){
        SQLiteDatabase db = this.getWritableDatabase();
        /*ContentValues cv = new ContentValues();
        cv.put("restaurantName", restaurantName);*/
        db.execSQL(" delete from "+ "alarm_table");
    }

    public int delete(String tableName, String where) {
        SQLiteDatabase db = getWritableDatabase();
        int deletedVal = -1;
        try {
            deletedVal = db.delete(tableName, where, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        db.close();
        return deletedVal;
    }
    public long sizeOfDatabase() {
        SQLiteDatabase db = this.getReadableDatabase();
        long size = DatabaseUtils.queryNumEntries(db, "alarm_table");
        //db.close();

        return size;
    }

    public String getID(Cursor c) { return c.getString(0);}

    public String getAlarmName(Cursor c){
        return(c.getString(1));
    }


    public String getDateandtime(Cursor c){
        return(c.getString(2));
    }
    public String getIntake(Cursor c){
        return(c.getString(3));
    }


}
