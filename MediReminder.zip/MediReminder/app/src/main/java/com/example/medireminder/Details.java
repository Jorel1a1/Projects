package com.example.medireminder;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class Details extends AppCompatActivity {
    private EditText name;
    private EditText intake;
    private TextView date;
    private Button bselect;
    private Button save;
    private AlarmHelper helper = null;

    private String alarmID = "";
    private String deleteAlarm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.details);

        name = findViewById(R.id.name);
        date = findViewById(R.id.date);
        intake = findViewById(R.id.intake);
        helper = new AlarmHelper(this);
        helper.getAll();

        bselect = findViewById(R.id.selection);
        save = findViewById(R.id.save);
        save.setOnClickListener(onSave);
        bselect.setOnClickListener(DateTimeSelection);
        alarmID = getIntent().getStringExtra("ID");



        if (alarmID != null) {
            load();
        }

    }
    private void load() {
        Cursor c = helper.getById(alarmID);
        c.moveToFirst();

        name.setText(helper.getAlarmName(c));
        intake.setText(helper.getIntake(c));
        date.setText(helper.getDateandtime(c));
        deleteAlarm = helper.getID(c);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        if(alarmID != null) {
            getMenuInflater().inflate(R.menu.option, menu);

        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {


            case (R.id.delete):
                Cursor c = helper.getById(alarmID);
                c.moveToFirst();
                AlertDialog.Builder builder1 = new AlertDialog.Builder(this);            //Create a pop-up dialog

                builder1.setMessage("Are you sure you want to delete ?");
                builder1.setCancelable(true);
                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                //String recordName = helper.getAlarmName(c);
                                //Date date = new Date(helper.getDateandtime(model));
                                //Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+8:00"));
                                //calendar.clear(date);
                                helper.delete("alarm_table", "_ID=" + deleteAlarm);
                                finish();
                            }
                        });
                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder1.create();                                           //Show the User the Alert Dialog
                alert.show();

        }
        return super.onOptionsItemSelected(item);
    }

    final Calendar newCalender = Calendar.getInstance();

    private View.OnClickListener DateTimeSelection = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            DatePickerDialog dialog = new DatePickerDialog(Details.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, final int year, final int month, final int dayOfMonth) {


                    final Calendar newDate = Calendar.getInstance();
                    Calendar newTime = Calendar.getInstance();
                    TimePickerDialog time = new TimePickerDialog(Details.this, new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                            newDate.set(year,month,dayOfMonth,hourOfDay,minute,0);
                            Calendar tem = Calendar.getInstance();
                            Log.w("TIME",System.currentTimeMillis()+"");
                            if(newDate.getTimeInMillis()-tem.getTimeInMillis()>0){
                                date.setText(newDate.getTime().toString());
                            }

                            else
                                Toast.makeText(Details.this,"Invalid time",Toast.LENGTH_SHORT).show();

                        }
                    },newTime.get(Calendar.HOUR_OF_DAY),newTime.get(Calendar.MINUTE),true);
                    time.show();

                }
            },newCalender.get(Calendar.YEAR),newCalender.get(Calendar.MONTH),newCalender.get(Calendar.DAY_OF_MONTH));

            dialog.getDatePicker().setMinDate(System.currentTimeMillis());
            dialog.show();
        }
    };
    private View.OnClickListener onSave = new View.OnClickListener(){
        @Override
        public void onClick (View v){
            if (name.getText().length() == 0 || date.getText().length() == 13 || intake.getText().length() == 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Details.this);            //Create a pop-up dialog

                builder.setMessage("Input fields cannot be empty!");
                builder.setCancelable(true);
                builder.setPositiveButton(
                        "Got it",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert = builder.create();                                           //Show the User the Alert Dialog
                alert.show();

            } else {
                Date remind = new Date(date.getText().toString());
                //To read data from restaurantName EditText
                String nameStr = name.getText().toString();
                //To read data from restaurantAddress EditText
                String dateStr = date.getText().toString();
                //To read data from restaurantTel EditText
                String intakeStr = intake.getText().toString();




                if (alarmID == null) {
                    //Insert record into SQLite tabl
                    helper.insert(nameStr, dateStr, intakeStr);
                    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+8:00"));
                    calendar.setTime(remind);
                    calendar.set(Calendar.SECOND,0);

                    Bundle bundle = new Bundle();
                    bundle.putString("MedName", nameStr);
                    bundle.putString("MedIntake", intakeStr);
                    Intent intent = new Intent(Details.this,NotifierAlarm.class);

                    intent.putExtras(bundle);

                    //intent.putExtra("Intake", intakeStr);
                    PendingIntent intent1 = PendingIntent.getBroadcast(Details.this,(int)helper.sizeOfDatabase(),intent,PendingIntent.FLAG_UPDATE_CURRENT);
                    AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),intent1);


                } else {
                    helper.update(alarmID, nameStr, dateStr, intakeStr);
                    int i = Integer.parseInt(alarmID);
                    Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+8:00"));
                    calendar.setTime(remind);
                    calendar.set(Calendar.SECOND,0);

                    Bundle bundle = new Bundle();
                    bundle.putString("MedName", nameStr);
                    bundle.putString("MedIntake", intakeStr);
                    Intent intent = new Intent(Details.this,NotifierAlarm.class);

                    intent.putExtras(bundle);


                    PendingIntent intent1 = PendingIntent.getBroadcast(Details.this,i,intent,PendingIntent.FLAG_UPDATE_CURRENT);
                    AlarmManager alarmManager = (AlarmManager)getSystemService(ALARM_SERVICE);
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),intent1);

                }
                finish();
            }



            //To close current Activity class and exit


        }
    };


}