package com.example.medireminder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.TextView;
import android.widget.Toast;

public class Sendingsms extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;
    private TextView nameMed;
    private TextView intakeMed;
    private String nameid;
    private String intakeid;
    private Cursor c = null;
    private PhoneNumberHelper helper1 = null;
    private String phoneID = "";
    private String phoneNo;
    private String message;
    private Button send;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sendingsms);
        Bundle bundle1 = getIntent().getExtras();
        nameMed = findViewById(R.id.nameMed);
        intakeMed = findViewById(R.id.intakeMed);
        send = findViewById(R.id.send);

        nameid = bundle1.getString("NameofMed");
        intakeid = bundle1.getString("IntakeofMed");

        nameMed.setText(nameid);
        intakeMed.setText(intakeid);

        helper1 = new PhoneNumberHelper(this);
        c = helper1.getAll();

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSMSMessage();
                //finish();
                Intent intent = new Intent(Sendingsms.this, AlarmList.class);
                startActivity(intent);
            }
        });
    }

    protected void sendSMSMessage() {
        c.moveToFirst();
        phoneNo = helper1.getPhoneNumber(c);
        message = "MediReminder: I have taken my" + nameid + " today!";

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNo, null, message, null, null);
        Toast.makeText(getApplicationContext(), "SMS sent.",
                Toast.LENGTH_LONG).show();
    }


}