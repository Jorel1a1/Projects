package com.example.medireminder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Date;


public class PhoneNumberHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "phonelist.db";
    private static final int SCHEMA_VERSION = 1;
    private SQLiteDatabase db;

    public PhoneNumberHelper(Context context) {
        super (context,DATABASE_NAME,null,SCHEMA_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        //Will be called once when the database is not created
        db.execSQL("CREATE TABLE phone_table ( _id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "phoneNumber TEXT);" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        //Will not be called until SCHEMA version increases
        //We can upgrade the database here e.g. add more tables
    }

    /*Read all records from restaurants_table */
    public Cursor getAll(){
        return (getReadableDatabase().rawQuery(
                "SELECT _id," +
                        " phoneNumber FROM phone_table ORDER BY phoneNumber",null));
    }

    /* Read a particular record from restaurants_table with id provided */
    public Cursor getById(String id) {
        String[] args = {id};
        return (getReadableDatabase().rawQuery(
                "SELECT _id," +
                        "phoneNumber FROM phone_table WHERE _ID = ?", args));
    }

    /*Writes a record into restaurants_table */
    public void insert(String phoneNumber){
        ContentValues cv = new ContentValues();

        cv.put("phoneNumber", phoneNumber);


        getWritableDatabase().insert("phone_table", "phoneNumber", cv);
    }

    /* Update a particular record in restaurants_table with id provided */
    public void update(String id, String phoneNumber) {
        ContentValues cv = new ContentValues();
        String[] args = {id};

        cv.put("phoneNumber", phoneNumber);


        getWritableDatabase().update("phone_table", cv, "_ID = ?", args);
    }

    public void delete (){
        SQLiteDatabase db = this.getWritableDatabase();
        /*ContentValues cv = new ContentValues();
        cv.put("restaurantName", restaurantName);*/
        db.execSQL(" delete from "+ "phone_table");
    }
    public long sizeOfDatabase() {
        SQLiteDatabase db = this.getReadableDatabase();
        long size = DatabaseUtils.queryNumEntries(db, "phone_table");
        //db.close();

        return size;
    }

    public String getID(Cursor c) { return c.getString(0);}

    public String getPhoneNumber(Cursor c){
        return(c.getString(1));
    }





}